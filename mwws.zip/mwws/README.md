# 🛒 MWWS — Mart When We Start

A simple online mart built with Streamlit. Customers browse by category, add to cart and order with cash on delivery.

## Features
- **Categories:** Laundry, Clothes, Household, Personal Care, Grocery (add more from Admin)
- Search, add to cart, quantity limits based on stock
- Delivery fee Rs 150, free over Rs 3,000
- Checkout with Pakistani mobile number check (03XX XXXXXXX)
- Optional "Send order on WhatsApp" button
- **Admin page:** edit products/prices/stock, add categories, view orders and change their status, download CSVs

## Run locally
```
pip install -r requirements.txt
streamlit run app.py
```

## Secrets (Streamlit Cloud → Manage app → Settings → Secrets)
```toml
ADMIN_PASSWORD = "choose-a-strong-password"   # required to open Admin
SHOP_WHATSAPP = "923001234567"                # optional, enables WhatsApp button
```

## Note
Products and orders are saved in CSV files. On Streamlit Cloud these reset when the app restarts or redeploys, so download orders regularly from Admin. For permanent storage, connect a database (e.g. Google Sheets or Supabase).
